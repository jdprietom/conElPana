
/**
 * Use los comentarios para explicar el objetivo de este programa MainTienda .
 *
 * @author (Sus Nombres y Apellidos y Su email)
 * @version (un numero de version o fecha, por ejemplo 0.01)
 */
class MainTienda
{
    /**Metodo principal (main) ejecutable*/
    public static void main(String [] args)
    {
        //Crear objeto del modelo "M" o negocio
        Tienda tienda = new Tienda();
        //Crear objeto Vista "V"
        Consola c = new Consola();

        //leer los datos de entrada y entregarlos al modelo, usa la Vista y el Modelo
        tienda.dineroInicial= c.leerEntero("Dinero Inicial");
        tienda.totalIngresos= c.leerEntero("Ingresos");
        tienda.totalEgresos= c.leerEntero("Egresos");

        //invocar el algoritmo o los algoritmos, usando el Modelo
        tienda.algoritmo();

        //mostrar / imprimir los datos de salida
        c.imprimir("Impuestos = " + tienda.valorImpuesto);
        c.imprimir("Ganancias Brutas = " + tienda.gananciasBrutas);        
        c.imprimir("Ganancias Netas = " + tienda.gananciasNetas);
        c.imprimir("Dinero Final = " + tienda.dineroFinal);      

    } 
    
}//fin class MainTienda
